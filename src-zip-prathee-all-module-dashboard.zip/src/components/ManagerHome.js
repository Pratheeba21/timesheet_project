// ManagerHome.js
import React from "react";
import { useAuth } from "../context/AuthContext";
import "./ManagerHome.css"; // Ensure this file exists for styling

const ManagerHome = () => {
  const { empId } = useAuth();

  return (
    <div className="manager-home-container">
      <h2>Welcome, Manager</h2>
      <p>Employee ID: {empId}</p>
      <p>We're glad to have you here!</p>
    </div>
  );
};

export default ManagerHome;
