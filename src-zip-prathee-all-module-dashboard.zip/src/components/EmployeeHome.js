// src/components/EmployeeHome.js
import React from "react";
import { useAuth } from "../context/AuthContext";
import "./Home.css"; // Create this file for styling

const EmployeeHome = () => {
  const { empId } = useAuth();

  return (
    <div className="employee-home-container">
      <div className="employee-home-content">
        <h2>Welcome, Employee</h2>
        <p>Employee ID: {empId}</p>
        <p>We're glad to have you here!</p>
      </div>
    </div>
  );
};

export default EmployeeHome;
