// ManagerSidebar.js
import React from "react";
import { FaTachometerAlt, FaCalendarAlt, FaSignOutAlt } from "react-icons/fa";
import "./ManagerSidebar.css";

const ManagerSidebar = ({ setActiveComponent }) => {
  return (
    <div className="manager-sidebar">
      <h2>Manager Dashboard</h2>
      <ul>
        <li onClick={() => setActiveComponent("home")}>
          <FaTachometerAlt /> Dashboard
        </li>
        <li onClick={() => setActiveComponent("view-timesheet")}>
          <FaCalendarAlt /> View Timesheet
        </li>
        <li
          onClick={() => {
            localStorage.removeItem("token");
            localStorage.removeItem("empId");
            window.location.href = "/login";
          }}
        >
          <FaSignOutAlt /> Logout
        </li>
      </ul>
    </div>
  );
};

export default ManagerSidebar;
